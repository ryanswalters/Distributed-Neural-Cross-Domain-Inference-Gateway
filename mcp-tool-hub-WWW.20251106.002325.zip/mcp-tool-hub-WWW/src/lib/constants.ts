   export const TOOL_CATEGORIES = {
      code: { label: 'Code', icon: '💻', color: 'bg-blue-500' },
      data: { label: 'Data', icon: '📊', color: 'bg-green-500' },
      web: { label: 'Web', icon: '🌐', color: 'bg-purple-500' },
      productivity: { label: 'Productivity', icon: '⚡', color: 'bg-orange-500' },
      ai: { label: 'AI', icon: '🤖', color: 'bg-pink-500' },
      system: { label: 'System', icon: '⚙️', color: 'bg-gray-500' },
      other: { label: 'Other', icon: '📦', color: 'bg-slate-500' }
    } as const


    export const TOOL_STATUS = {
      enabled: { label: 'Enabled', color: 'bg-green-500' },
      disabled: { label: 'Disabled', color: 'bg-gray-400' },
      'needs-config': { label: 'Needs Config', color: 'bg-amber-500' }
    } as const


    export const WORKFLOW_STEP_TYPES = {
      'web-api': { label: 'Web API', icon: '🌐', color: 'bg-blue-500' },
      'file-op': { label: 'File Operation', icon: '📁', color: 'bg-green-500' },
      'ai-call': { label: 'AI Call', icon: '🤖', color: 'bg-purple-500' },
      'transform': { label: 'Transform', icon: '🔄', color: 'bg-orange-500' },
      'conditional': { label: 'Conditional', icon: '🔀', color: 'bg-yellow-500' }
    } as const


    export const MCP_SERVER_CATEGORIES = {
      official: { label: 'Official', color: 'bg-blue-500' },
      community: { label: 'Community', color: 'bg-green-500' },
      commercial: { label: 'Commercial', color: 'bg-purple-500' }
    } as const


    export const MCP_DIFFICULTY_LEVELS = {
      beginner: { label: 'Beginner', color: 'bg-green-500' },
      intermediate: { label: 'Intermediate', color: 'bg-yellow-500' },
      advanced: { label: 'Advanced', color: 'bg-red-500' }
    } as const
    export const STORAGE_KEYS = {
      TOOLS: 'mcp_tool_hub_tools',
      WORKFLOWS: 'mcp_tool_hub_workflows'
    } as const  

